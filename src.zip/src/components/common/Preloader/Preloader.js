import preloader from '../../../my_img/loading.gif';

let Preloader = (props) => {
    return (
        <img src={preloader}/>
    )
}   

export default Preloader;