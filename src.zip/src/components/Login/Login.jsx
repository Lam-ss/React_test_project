




const Login = (props) => {
    return (
        <h1>LOGIN</h1>
    )
}

export default Login;